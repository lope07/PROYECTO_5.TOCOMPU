﻿
namespace PROYECTO_ECUACIONES
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txta2 = new System.Windows.Forms.TextBox();
            this.txtb2 = new System.Windows.Forms.TextBox();
            this.txtc2 = new System.Windows.Forms.TextBox();
            this.txtb1 = new System.Windows.Forms.TextBox();
            this.txtc1 = new System.Windows.Forms.TextBox();
            this.txta1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.lblRespuestaY = new System.Windows.Forms.Label();
            this.lblRepuestaX = new System.Windows.Forms.Label();
            this.lblRX = new System.Windows.Forms.Label();
            this.lblY = new System.Windows.Forms.Label();
            this.lblX = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.AliceBlue;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(502, 8);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(63, 58);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(108, 155);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 20);
            this.label5.TabIndex = 22;
            this.label5.Text = "+";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(108, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 20);
            this.label4.TabIndex = 21;
            this.label4.Text = "+";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(240, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 20);
            this.label3.TabIndex = 20;
            this.label3.Text = "=";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(240, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 20);
            this.label2.TabIndex = 19;
            this.label2.Text = "=";
            // 
            // txta2
            // 
            this.txta2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txta2.Location = new System.Drawing.Point(14, 155);
            this.txta2.Name = "txta2";
            this.txta2.Size = new System.Drawing.Size(75, 23);
            this.txta2.TabIndex = 18;
            this.txta2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtb2
            // 
            this.txtb2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtb2.Location = new System.Drawing.Point(148, 155);
            this.txtb2.Name = "txtb2";
            this.txtb2.Size = new System.Drawing.Size(65, 23);
            this.txtb2.TabIndex = 17;
            this.txtb2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtc2
            // 
            this.txtc2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtc2.Location = new System.Drawing.Point(295, 152);
            this.txtc2.Name = "txtc2";
            this.txtc2.Size = new System.Drawing.Size(81, 23);
            this.txtc2.TabIndex = 16;
            this.txtc2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtb1
            // 
            this.txtb1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtb1.Location = new System.Drawing.Point(148, 83);
            this.txtb1.Name = "txtb1";
            this.txtb1.Size = new System.Drawing.Size(65, 23);
            this.txtb1.TabIndex = 15;
            this.txtb1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtc1
            // 
            this.txtc1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtc1.Location = new System.Drawing.Point(295, 81);
            this.txtc1.Name = "txtc1";
            this.txtc1.Size = new System.Drawing.Size(81, 23);
            this.txtc1.TabIndex = 14;
            this.txtc1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txta1
            // 
            this.txta1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txta1.Location = new System.Drawing.Point(14, 88);
            this.txta1.Name = "txta1";
            this.txta1.Size = new System.Drawing.Size(75, 23);
            this.txta1.TabIndex = 13;
            this.txta1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.AliceBlue;
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Location = new System.Drawing.Point(425, 88);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(83, 77);
            this.button2.TabIndex = 23;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lblRespuestaY
            // 
            this.lblRespuestaY.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblRespuestaY.AutoSize = true;
            this.lblRespuestaY.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRespuestaY.Location = new System.Drawing.Point(339, 432);
            this.lblRespuestaY.Name = "lblRespuestaY";
            this.lblRespuestaY.Size = new System.Drawing.Size(0, 23);
            this.lblRespuestaY.TabIndex = 37;
            this.lblRespuestaY.UseMnemonic = false;
            // 
            // lblRepuestaX
            // 
            this.lblRepuestaX.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblRepuestaX.AutoSize = true;
            this.lblRepuestaX.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRepuestaX.Location = new System.Drawing.Point(339, 369);
            this.lblRepuestaX.Name = "lblRepuestaX";
            this.lblRepuestaX.Size = new System.Drawing.Size(0, 23);
            this.lblRepuestaX.TabIndex = 36;
            // 
            // lblRX
            // 
            this.lblRX.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblRX.AutoSize = true;
            this.lblRX.Location = new System.Drawing.Point(195, 209);
            this.lblRX.Name = "lblRX";
            this.lblRX.Size = new System.Drawing.Size(0, 15);
            this.lblRX.TabIndex = 35;
            // 
            // lblY
            // 
            this.lblY.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblY.AutoSize = true;
            this.lblY.Location = new System.Drawing.Point(194, 279);
            this.lblY.Name = "lblY";
            this.lblY.Size = new System.Drawing.Size(0, 15);
            this.lblY.TabIndex = 34;
            // 
            // lblX
            // 
            this.lblX.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblX.AutoSize = true;
            this.lblX.Location = new System.Drawing.Point(195, 163);
            this.lblX.Name = "lblX";
            this.lblX.Size = new System.Drawing.Size(0, 15);
            this.lblX.TabIndex = 33;
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(274, 212);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(103, 20);
            this.label12.TabIndex = 32;
            this.label12.Text = "Proceso de Y";
            this.label12.Visible = false;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(-2, 209);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 23);
            this.label11.TabIndex = 31;
            this.label11.Text = "Procesos de X";
            this.label11.Visible = false;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(6, 432);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(218, 36);
            this.label8.TabIndex = 30;
            this.label8.Text = "solucion de y: ";
            this.label8.Visible = false;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(7, 396);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(217, 36);
            this.label6.TabIndex = 29;
            this.label6.Text = "solucion de x: ";
            this.label6.Visible = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(577, 473);
            this.Controls.Add(this.lblRespuestaY);
            this.Controls.Add(this.lblRepuestaX);
            this.Controls.Add(this.lblRX);
            this.Controls.Add(this.lblY);
            this.Controls.Add(this.lblX);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txta2);
            this.Controls.Add(this.txtb2);
            this.Controls.Add(this.txtc2);
            this.Controls.Add(this.txtb1);
            this.Controls.Add(this.txtc1);
            this.Controls.Add(this.txta1);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Leelawadee", 9.75F);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txta2;
        private System.Windows.Forms.TextBox txtb2;
        private System.Windows.Forms.TextBox txtc2;
        private System.Windows.Forms.TextBox txtb1;
        private System.Windows.Forms.TextBox txtc1;
        private System.Windows.Forms.TextBox txta1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lblRespuestaY;
        private System.Windows.Forms.Label lblRepuestaX;
        private System.Windows.Forms.Label lblRX;
        private System.Windows.Forms.Label lblY;
        private System.Windows.Forms.Label lblX;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
    }
}