﻿
namespace PROYECTO_ECUACIONES
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txta2 = new System.Windows.Forms.TextBox();
            this.txtb2 = new System.Windows.Forms.TextBox();
            this.txtc2 = new System.Windows.Forms.TextBox();
            this.txtb1 = new System.Windows.Forms.TextBox();
            this.txtc1 = new System.Windows.Forms.TextBox();
            this.txta1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblMostrarSoluY = new System.Windows.Forms.Label();
            this.lblMostrarSoluc = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.AliceBlue;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(425, 95);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 86);
            this.button1.TabIndex = 85;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(137, 175);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 20);
            this.label5.TabIndex = 84;
            this.label5.Text = "+";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(137, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 20);
            this.label4.TabIndex = 83;
            this.label4.Text = "+";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(274, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(18, 20);
            this.label3.TabIndex = 82;
            this.label3.Text = "=";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(274, 174);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(18, 20);
            this.label2.TabIndex = 81;
            this.label2.Text = "=";
            // 
            // txta2
            // 
            this.txta2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txta2.Location = new System.Drawing.Point(12, 176);
            this.txta2.Name = "txta2";
            this.txta2.Size = new System.Drawing.Size(107, 23);
            this.txta2.TabIndex = 80;
            this.txta2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtb2
            // 
            this.txtb2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtb2.Location = new System.Drawing.Point(161, 175);
            this.txtb2.Name = "txtb2";
            this.txtb2.Size = new System.Drawing.Size(99, 23);
            this.txtb2.TabIndex = 79;
            this.txtb2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtc2
            // 
            this.txtc2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtc2.Location = new System.Drawing.Point(298, 172);
            this.txtc2.Name = "txtc2";
            this.txtc2.Size = new System.Drawing.Size(84, 23);
            this.txtc2.TabIndex = 78;
            this.txtc2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtb1
            // 
            this.txtb1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtb1.Location = new System.Drawing.Point(161, 92);
            this.txtb1.Name = "txtb1";
            this.txtb1.Size = new System.Drawing.Size(99, 23);
            this.txtb1.TabIndex = 77;
            this.txtb1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtc1
            // 
            this.txtc1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtc1.Location = new System.Drawing.Point(298, 89);
            this.txtc1.Name = "txtc1";
            this.txtc1.Size = new System.Drawing.Size(84, 23);
            this.txtc1.TabIndex = 76;
            this.txtc1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txta1
            // 
            this.txta1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txta1.Location = new System.Drawing.Point(12, 96);
            this.txta1.Name = "txta1";
            this.txta1.Size = new System.Drawing.Size(107, 23);
            this.txta1.TabIndex = 75;
            this.txta1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(341, 257);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 31);
            this.label9.TabIndex = 89;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(341, 193);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 31);
            this.label7.TabIndex = 88;
            // 
            // lblMostrarSoluY
            // 
            this.lblMostrarSoluY.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblMostrarSoluY.AutoSize = true;
            this.lblMostrarSoluY.Font = new System.Drawing.Font("Leelawadee", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostrarSoluY.Location = new System.Drawing.Point(272, 257);
            this.lblMostrarSoluY.Name = "lblMostrarSoluY";
            this.lblMostrarSoluY.Size = new System.Drawing.Size(184, 32);
            this.lblMostrarSoluY.TabIndex = 87;
            this.lblMostrarSoluY.Text = "solucion de y: ";
            // 
            // lblMostrarSoluc
            // 
            this.lblMostrarSoluc.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblMostrarSoluc.AutoSize = true;
            this.lblMostrarSoluc.Font = new System.Drawing.Font("Leelawadee", 20.25F);
            this.lblMostrarSoluc.Location = new System.Drawing.Point(0, 257);
            this.lblMostrarSoluc.Name = "lblMostrarSoluc";
            this.lblMostrarSoluc.Size = new System.Drawing.Size(183, 32);
            this.lblMostrarSoluc.TabIndex = 86;
            this.lblMostrarSoluc.Text = "solucion de x: ";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SkyBlue;
            this.ClientSize = new System.Drawing.Size(577, 473);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblMostrarSoluY);
            this.Controls.Add(this.lblMostrarSoluc);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txta2);
            this.Controls.Add(this.txtb2);
            this.Controls.Add(this.txtc2);
            this.Controls.Add(this.txtb1);
            this.Controls.Add(this.txtc1);
            this.Controls.Add(this.txta1);
            this.Font = new System.Drawing.Font("Leelawadee", 9.75F);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txta2;
        private System.Windows.Forms.TextBox txtb2;
        private System.Windows.Forms.TextBox txtc2;
        private System.Windows.Forms.TextBox txtb1;
        private System.Windows.Forms.TextBox txtc1;
        private System.Windows.Forms.TextBox txta1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblMostrarSoluY;
        private System.Windows.Forms.Label lblMostrarSoluc;
    }
}