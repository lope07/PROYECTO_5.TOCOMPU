﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROYECTO_ECUACIONES
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float a = Convert.ToSingle(txta1.Text);
            float b = Convert.ToSingle(txtb1.Text);
            float c = Convert.ToSingle(txta2.Text); //txtb2.Text
            float d = Convert.ToSingle(txtb2.Text);
            float e2 = Convert.ToSingle(txtc1.Text);
            float f = Convert.ToSingle(txtc2.Text);


            float determinante = a * d - b * c;

            if (determinante == 0)
            {
                MessageBox.Show("erro.");
            }
            else
            {
                // Calcular las soluciones utilizando la fórmula de Cramer
                float x = (e2 * d - b * f) / determinante;
                float y = (a * f - c * e2) / determinante;



                label7.Text = x.ToString();
                label9.Text = y.ToString();
            }
        }
    }
}
