﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;


namespace PROYECTO_ECUACIONES
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string uno = textBox1.Text;
            string dos   = textBox3.Text;
            string tres  = textBox4.Text;

            string resol = $"(y + {uno})² = {tres}(x - {dos})";
            

           
            
                double k = double.Parse(uno);
                double h = double.Parse(dos);
                double a = double.Parse(tres);

                // Calcular el vértice
                double vertexX = h;
                double vertexY = -k;

                // Calcular el foco
                double focusX = h;
                double focusY = -k + 1 / (4 * a);

                // Calcular la directriz
                double directrixY = -k - 1 / (4 * a);

                // Generar la ecuación en forma canónica
                string canonicalEquation = $"(y + {k})² = {4 * a}(x - {h})";


                // Graficar la parábola
                Series series = new Series();
                series.ChartType = SeriesChartType.Spline;

                for (double x = -10; x <= 10; x += 0.01)
                {
                    double y = Math.Pow(4 * a * (x - h), 0.5) - k;
                    series.Points.AddXY(x, y);
                }


                chart1.Series.Clear();
                chart1.Series.Add(series);
                chart1.Series.Add(new Series

                {
                    ChartType = SeriesChartType.Point,
                    MarkerStyle = MarkerStyle.Circle,
                    MarkerSize = 8,
                    Points = { new DataPoint(focusX, focusY) }
                });

                Series directrixSeries = new Series
                {
                    ChartType = SeriesChartType.Line
                };

                for (double x = -10; x <= 10; x += 0.1)
                {
                    double y = directrixY;
                    directrixSeries.Points.AddXY(x, y);
                }


                //recta de directriz
                chart1.Series.Add(directrixSeries);

            
            
                
            
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            chart1.ChartAreas[0].AxisX.Minimum = -10;
            chart1.ChartAreas[0].AxisX.Maximum = 10;
            chart1.ChartAreas[0].AxisX.Interval = 1;
            chart1.ChartAreas[0].AxisY.Minimum = -10;
            chart1.ChartAreas[0].AxisY.Maximum = 10;
            chart1.ChartAreas[0].AxisY.Interval = 1;
            chart1.ChartAreas[0].AxisY.Interval = .25;
        }
    }
}
