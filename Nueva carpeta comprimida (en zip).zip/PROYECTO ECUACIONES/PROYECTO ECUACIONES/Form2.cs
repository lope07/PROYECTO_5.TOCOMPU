﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROYECTO_ECUACIONES
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label6.Visible = true;
            label8.Visible = true;
            label11.Visible = true;
            label12.Visible = true;

            double a1 = Convert.ToDouble(txta1.Text);
            double b1 = Convert.ToDouble(txtb1.Text);
            double c1 = Convert.ToDouble(txtc1.Text);
            double a2 = Convert.ToDouble(txta2.Text);
            double b2 = Convert.ToDouble(txtb2.Text);
            double c2 = Convert.ToDouble(txtc2.Text);

            // Resolución de la primera ecuación para x
            double x = (c1 - b1 * (c2 / b2)) / (a1 - b1 * (a2 / b2));

            // Sustitución del valor de x en la segunda ecuación
            double y = (c2 - a2 * x) / b2;
            lblX.Text = " x = (" + c1 + " - " + b1 + " * (" + c2 + " / " + b2 + ")) / (" + a1 + " - " + b1 + " * (" + a2 + " / " + b2 + "))";
            lblRX.Text = x.ToString();
            lblY.Text = "y = (" + c2 + " - " + a2 + " * " + x + ") / " + b2 + "";

            lblRepuestaX.Text = x.ToString();
            lblRespuestaY.Text = y.ToString();
        }
    }
}
