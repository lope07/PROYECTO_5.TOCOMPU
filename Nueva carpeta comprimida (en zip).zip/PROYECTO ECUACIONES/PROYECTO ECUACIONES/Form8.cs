﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROYECTO_ECUACIONES
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string xd = textBox1.Text;


            string[] coefficients = xd.Split(new char[] { 'x', 'y', '=', '+' }, StringSplitOptions.RemoveEmptyEntries);

            double a = double.Parse(coefficients[0]);
            double b = double.Parse(coefficients[1]);


            double x1 = 1;
            double y1 = -(a / b) * x1;
            double x2 = -2;
            double y2 = -(a / b) * x2;

            chartLine.ChartAreas[0].AxisX.Minimum = -10;
            chartLine.ChartAreas[0].AxisX.Maximum = 10;
            chartLine.ChartAreas[0].AxisX.Interval = 1;
            chartLine.ChartAreas[0].AxisY.Minimum = -10;
            chartLine.ChartAreas[0].AxisY.Maximum = 10;
            chartLine.ChartAreas[0].AxisY.Interval = 1;
            chartLine.ChartAreas[0].AxisY.Interval = .5;

            label1.Text = $"Punto 1: ({x1}, {y1})\nPunto 2: ({x2}, {y2})";
        }
    }
}
