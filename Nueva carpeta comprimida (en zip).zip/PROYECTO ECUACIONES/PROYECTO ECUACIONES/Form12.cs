﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;


namespace PROYECTO_ECUACIONES
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Obtener los valores ingresados en los TextBoxes
            double X = double.Parse(textBox1.Text);
            double Y = double.Parse(textBox2.Text);
            double semiMajorAxis = double.Parse(textBox3.Text);
            double semiMinorAxis = double.Parse(textBox4.Text);



            // Limpiar la gráfica
            chart1.Series.Clear();

            // Crear una nueva serie para la elipse
            Series series = new Series();
            series.ChartType = SeriesChartType.Point;
            series.Color = Color.Blue;

            // Calcular los puntos de la elipse y agregarlos a la serie
            int numPoints = 100;
            for (int i = 0; i < numPoints; i++)
            {
                double angle = 2 * Math.PI * i / numPoints;
                double x = X + semiMajorAxis * Math.Cos(angle);
                double y = Y + semiMinorAxis * Math.Sin(angle);
                series.Points.AddXY(x, y);


            }

            // Marcar el centro de la elipse en la gráfica
            Series centerSeries = new Series();
            centerSeries.ChartType = SeriesChartType.Point;
            centerSeries.Color = Color.Red;
            centerSeries.Points.AddXY(X,Y);
            chart1.Series.Add(centerSeries);

            // Dibujar una línea vertical desde el centro de la elipse hasta el círculo superior
            Series lineVerticalSeries = new Series();
            lineVerticalSeries.ChartType = SeriesChartType.Line;
            lineVerticalSeries.Color = Color.Green;
            lineVerticalSeries.Points.AddXY(X, Y - semiMinorAxis);
            lineVerticalSeries.Points.AddXY(X, Y - semiMajorAxis);
            lineVerticalSeries.Points.AddXY(X, Y);
            chart1.Series.Add(lineVerticalSeries);


            // Dibujar una línea horizontal desde el centro de la elipse hasta el círculo derecho
            Series lineHorizontalSeries = new Series();
            lineHorizontalSeries.ChartType = SeriesChartType.Line;
            lineHorizontalSeries.Color = Color.Orange;
            lineHorizontalSeries.Points.AddXY(X, Y);
            lineHorizontalSeries.Points.AddXY(X + semiMajorAxis, Y);
            chart1.Series.Add(lineHorizontalSeries);

            // Agregar la serie a la gráfica
            chart1.Series.Add(series);

            // Configurar los ejes
            chart1.ChartAreas[0].AxisX.Minimum = X - semiMajorAxis;
            chart1.ChartAreas[0].AxisX.Maximum = X + semiMajorAxis;
            chart1.ChartAreas[0].AxisX.Interval = .25;

            chart1.ChartAreas[0].AxisY.Minimum = Y - semiMinorAxis;
            chart1.ChartAreas[0].AxisY.Maximum = Y + semiMinorAxis;
            chart1.ChartAreas[0].AxisY.Interval = .25;
        }
    }
}
