﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROYECTO_ECUACIONES
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float a = Convert.ToSingle(txta1.Text);
            float b = Convert.ToSingle(txtb1.Text);
            float c = Convert.ToSingle(txtc1.Text);
            float d = Convert.ToSingle(txta2.Text);
            float e2 = Convert.ToSingle(txtb2.Text);
            float f = Convert.ToSingle(txtc2.Text);

            float factor = d / a;
            d -= factor * a;
            e2 -= factor * b;
            f -= factor * c;

            float y = f / e2;
            float x = (c - b * y) / a;

            label7.Text = x.ToString();
            label9.Text = y.ToString();
        }

        private void txta1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
