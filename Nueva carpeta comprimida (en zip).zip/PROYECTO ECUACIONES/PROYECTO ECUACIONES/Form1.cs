﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROYECTO_ECUACIONES
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Diseno();
        }

        private void Diseno()
        {
            panel_algebra.Visible = false;
            panel_mate.Visible = false;
        }
        private void HideSubMenu()
        {
            if (panel_algebra.Visible == true)
                panel_algebra.Visible = false;
            if (panel_mate.Visible == true)
                panel_mate.Visible = false;

        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                HideSubMenu();
                subMenu.Visible = true;
            }
            else
            {
                subMenu.Visible = false;
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            OpenCHildForm(new Form7());
            HideSubMenu();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnMedios_Click(object sender, EventArgs e)
        {
            showSubMenu(panel_algebra);

        }

        private void btn_sustitucion_Click(object sender, EventArgs e)
        {
            OpenCHildForm(new Form2());
            HideSubMenu();
        }

        private void btn_eliminacion_Click(object sender, EventArgs e)
        {
            OpenCHildForm(new Form3());
            HideSubMenu();
        }

        private void btn_igualacion_Click(object sender, EventArgs e)
        {
            OpenCHildForm(new Form4());
            HideSubMenu();
        }

        private void btn_determinantes_Click(object sender, EventArgs e)
        {
            OpenCHildForm(new Form5());
            HideSubMenu();
        }

        private void btn_grafica_Click(object sender, EventArgs e)
        {
            OpenCHildForm(new Form6());
            HideSubMenu();
        }

        private void btn_mate_Click(object sender, EventArgs e)
        {
            showSubMenu(panel_mate);
        }
        private Form activeform = null;
        private void OpenCHildForm(Form childForm)
        {
            if (activeform != null)
                activeform.Close();
            activeform = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelChildForm.Controls.Add(childForm);
            panelChildForm.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();


        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click_1(object sender, EventArgs e)
        {

        }

        private void button6_Click_2(object sender, EventArgs e)
        {
            OpenCHildForm(new Form8());
            HideSubMenu();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenCHildForm(new Form9());
            HideSubMenu();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenCHildForm(new Form10());
            HideSubMenu();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenCHildForm(new Form11());
            HideSubMenu();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenCHildForm(new Form12());
            HideSubMenu();
        }
    }
}
