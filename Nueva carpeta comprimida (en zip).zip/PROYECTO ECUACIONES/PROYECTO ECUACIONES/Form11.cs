﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;



namespace PROYECTO_ECUACIONES
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double uno = double.Parse(textBox1.Text);
            double dos = double.Parse(textBox2.Text); //foco

            // Calcular "a" y "b" usando los valores proporcionados
            double a = dos / 2;
            double b = Math.Sqrt(uno * uno - a * a);

            // Generar la ecuación de la hiperbola
            string ecuacion = $"(x² / {a * a}) - (y² / {b * b}) = 1";


            // Mostrar el resultado en los Labels
            label1.Text = ecuacion;
          

            // Limpiar la gráfica antes de dibujar la nueva hiperbola
            chart1.Series.Clear();

            // Crear una nueva serie para la hiperbola
            Series hiperbolaSerie = new Series();
            hiperbolaSerie.ChartType = SeriesChartType.Spline;
            hiperbolaSerie.BorderWidth = 2;
            hiperbolaSerie.Color = System.Drawing.Color.Blue;

            // Agregar puntos a la serie para dibujar la hiperbola
            for (double x = -a * 3; x <= a * 3; x += 0.1)
            {
                double y = Math.Sqrt(b * b * (1 + x * x / (a * a)));
                hiperbolaSerie.Points.AddXY(x, y);
                hiperbolaSerie.Points.AddXY(x, -y);
            }

            // Agregar la serie a la gráfica
            chart1.Series.Add(hiperbolaSerie);

            // Agregar el punto del centro de la hiperbola
            Series centroSerie = new Series();
            centroSerie.ChartType = SeriesChartType.Point;
            centroSerie.MarkerSize = 10;
            centroSerie.Color = System.Drawing.Color.Red;
            centroSerie.Points.AddXY(0, 0); // Coordenadas del centro
            chart1.Series.Add(centroSerie);
        }
    }
}
