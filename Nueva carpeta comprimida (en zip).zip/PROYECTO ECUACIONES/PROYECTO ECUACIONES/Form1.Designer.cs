﻿
namespace PROYECTO_ECUACIONES
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel_lateral = new System.Windows.Forms.Panel();
            this.panel_mate = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.btn_mate = new System.Windows.Forms.Button();
            this.panel_algebra = new System.Windows.Forms.Panel();
            this.btn_grafica = new System.Windows.Forms.Button();
            this.btn_vectores = new System.Windows.Forms.Button();
            this.btn_determinantes = new System.Windows.Forms.Button();
            this.btn_igualacion = new System.Windows.Forms.Button();
            this.btn_eliminacion = new System.Windows.Forms.Button();
            this.btn_sustitucion = new System.Windows.Forms.Button();
            this.btnMedios = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panelChildForm = new System.Windows.Forms.Panel();
            this.panel_lateral.SuspendLayout();
            this.panel_mate.SuspendLayout();
            this.panel_algebra.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_lateral
            // 
            this.panel_lateral.AutoScroll = true;
            this.panel_lateral.BackColor = System.Drawing.Color.AliceBlue;
            this.panel_lateral.Controls.Add(this.panel_mate);
            this.panel_lateral.Controls.Add(this.btn_mate);
            this.panel_lateral.Controls.Add(this.panel_algebra);
            this.panel_lateral.Controls.Add(this.btnMedios);
            this.panel_lateral.Controls.Add(this.panel1);
            this.panel_lateral.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_lateral.Location = new System.Drawing.Point(0, 0);
            this.panel_lateral.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel_lateral.Name = "panel_lateral";
            this.panel_lateral.Size = new System.Drawing.Size(219, 575);
            this.panel_lateral.TabIndex = 0;
            // 
            // panel_mate
            // 
            this.panel_mate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(246)))), ((int)(((byte)(244)))));
            this.panel_mate.Controls.Add(this.button2);
            this.panel_mate.Controls.Add(this.button3);
            this.panel_mate.Controls.Add(this.button4);
            this.panel_mate.Controls.Add(this.button5);
            this.panel_mate.Controls.Add(this.button6);
            this.panel_mate.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_mate.Location = new System.Drawing.Point(0, 322);
            this.panel_mate.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel_mate.Name = "panel_mate";
            this.panel_mate.Size = new System.Drawing.Size(219, 116);
            this.panel_mate.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.SkyBlue;
            this.button2.Dock = System.Windows.Forms.DockStyle.Top;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Leelawadee", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(0, 92);
            this.button2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.button2.Size = new System.Drawing.Size(219, 24);
            this.button2.TabIndex = 4;
            this.button2.Text = "Elipse";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.SkyBlue;
            this.button3.Dock = System.Windows.Forms.DockStyle.Top;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(0, 71);
            this.button3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button3.Name = "button3";
            this.button3.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.button3.Size = new System.Drawing.Size(219, 21);
            this.button3.TabIndex = 3;
            this.button3.Text = "Hiberbola...";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.SkyBlue;
            this.button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(0, 45);
            this.button4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button4.Name = "button4";
            this.button4.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.button4.Size = new System.Drawing.Size(219, 26);
            this.button4.TabIndex = 2;
            this.button4.Text = "Circunferencias";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.SkyBlue;
            this.button5.Dock = System.Windows.Forms.DockStyle.Top;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.Color.Black;
            this.button5.Location = new System.Drawing.Point(0, 24);
            this.button5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button5.Name = "button5";
            this.button5.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.button5.Size = new System.Drawing.Size(219, 21);
            this.button5.TabIndex = 1;
            this.button5.Text = "Parabolas";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.SkyBlue;
            this.button6.Dock = System.Windows.Forms.DockStyle.Top;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.ForeColor = System.Drawing.Color.Black;
            this.button6.Location = new System.Drawing.Point(0, 0);
            this.button6.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.button6.Name = "button6";
            this.button6.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.button6.Size = new System.Drawing.Size(219, 24);
            this.button6.TabIndex = 0;
            this.button6.Text = "Rectas";
            this.button6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click_2);
            // 
            // btn_mate
            // 
            this.btn_mate.BackColor = System.Drawing.Color.AliceBlue;
            this.btn_mate.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_mate.FlatAppearance.BorderSize = 0;
            this.btn_mate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_mate.ForeColor = System.Drawing.Color.Black;
            this.btn_mate.Location = new System.Drawing.Point(0, 274);
            this.btn_mate.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_mate.Name = "btn_mate";
            this.btn_mate.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.btn_mate.Size = new System.Drawing.Size(219, 48);
            this.btn_mate.TabIndex = 3;
            this.btn_mate.Text = "Matematicas";
            this.btn_mate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_mate.UseVisualStyleBackColor = false;
            this.btn_mate.Click += new System.EventHandler(this.btn_mate_Click);
            // 
            // panel_algebra
            // 
            this.panel_algebra.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(246)))), ((int)(((byte)(244)))));
            this.panel_algebra.Controls.Add(this.btn_grafica);
            this.panel_algebra.Controls.Add(this.btn_vectores);
            this.panel_algebra.Controls.Add(this.btn_determinantes);
            this.panel_algebra.Controls.Add(this.btn_igualacion);
            this.panel_algebra.Controls.Add(this.btn_eliminacion);
            this.panel_algebra.Controls.Add(this.btn_sustitucion);
            this.panel_algebra.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_algebra.Location = new System.Drawing.Point(0, 136);
            this.panel_algebra.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel_algebra.Name = "panel_algebra";
            this.panel_algebra.Size = new System.Drawing.Size(219, 138);
            this.panel_algebra.TabIndex = 2;
            // 
            // btn_grafica
            // 
            this.btn_grafica.BackColor = System.Drawing.Color.SkyBlue;
            this.btn_grafica.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_grafica.FlatAppearance.BorderSize = 0;
            this.btn_grafica.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_grafica.ForeColor = System.Drawing.Color.Black;
            this.btn_grafica.Location = new System.Drawing.Point(0, 113);
            this.btn_grafica.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_grafica.Name = "btn_grafica";
            this.btn_grafica.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.btn_grafica.Size = new System.Drawing.Size(219, 25);
            this.btn_grafica.TabIndex = 5;
            this.btn_grafica.Text = "Forma Grafica";
            this.btn_grafica.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_grafica.UseVisualStyleBackColor = false;
            this.btn_grafica.Click += new System.EventHandler(this.btn_grafica_Click);
            // 
            // btn_vectores
            // 
            this.btn_vectores.BackColor = System.Drawing.Color.SkyBlue;
            this.btn_vectores.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_vectores.FlatAppearance.BorderSize = 0;
            this.btn_vectores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_vectores.ForeColor = System.Drawing.Color.Black;
            this.btn_vectores.Location = new System.Drawing.Point(0, 92);
            this.btn_vectores.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_vectores.Name = "btn_vectores";
            this.btn_vectores.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.btn_vectores.Size = new System.Drawing.Size(219, 21);
            this.btn_vectores.TabIndex = 4;
            this.btn_vectores.Text = "Vectores";
            this.btn_vectores.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_vectores.UseVisualStyleBackColor = false;
            this.btn_vectores.Click += new System.EventHandler(this.button6_Click);
            // 
            // btn_determinantes
            // 
            this.btn_determinantes.BackColor = System.Drawing.Color.SkyBlue;
            this.btn_determinantes.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_determinantes.FlatAppearance.BorderSize = 0;
            this.btn_determinantes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_determinantes.ForeColor = System.Drawing.Color.Black;
            this.btn_determinantes.Location = new System.Drawing.Point(0, 71);
            this.btn_determinantes.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_determinantes.Name = "btn_determinantes";
            this.btn_determinantes.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.btn_determinantes.Size = new System.Drawing.Size(219, 21);
            this.btn_determinantes.TabIndex = 3;
            this.btn_determinantes.Text = "Determinantes";
            this.btn_determinantes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_determinantes.UseVisualStyleBackColor = false;
            this.btn_determinantes.Click += new System.EventHandler(this.btn_determinantes_Click);
            // 
            // btn_igualacion
            // 
            this.btn_igualacion.BackColor = System.Drawing.Color.SkyBlue;
            this.btn_igualacion.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_igualacion.FlatAppearance.BorderSize = 0;
            this.btn_igualacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_igualacion.ForeColor = System.Drawing.Color.Black;
            this.btn_igualacion.Location = new System.Drawing.Point(0, 45);
            this.btn_igualacion.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_igualacion.Name = "btn_igualacion";
            this.btn_igualacion.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.btn_igualacion.Size = new System.Drawing.Size(219, 26);
            this.btn_igualacion.TabIndex = 2;
            this.btn_igualacion.Text = "Igualacion";
            this.btn_igualacion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_igualacion.UseVisualStyleBackColor = false;
            this.btn_igualacion.Click += new System.EventHandler(this.btn_igualacion_Click);
            // 
            // btn_eliminacion
            // 
            this.btn_eliminacion.BackColor = System.Drawing.Color.SkyBlue;
            this.btn_eliminacion.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_eliminacion.FlatAppearance.BorderSize = 0;
            this.btn_eliminacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_eliminacion.ForeColor = System.Drawing.Color.Black;
            this.btn_eliminacion.Location = new System.Drawing.Point(0, 24);
            this.btn_eliminacion.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_eliminacion.Name = "btn_eliminacion";
            this.btn_eliminacion.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.btn_eliminacion.Size = new System.Drawing.Size(219, 21);
            this.btn_eliminacion.TabIndex = 1;
            this.btn_eliminacion.Text = "Eliminacion";
            this.btn_eliminacion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_eliminacion.UseVisualStyleBackColor = false;
            this.btn_eliminacion.Click += new System.EventHandler(this.btn_eliminacion_Click);
            // 
            // btn_sustitucion
            // 
            this.btn_sustitucion.BackColor = System.Drawing.Color.SkyBlue;
            this.btn_sustitucion.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_sustitucion.FlatAppearance.BorderSize = 0;
            this.btn_sustitucion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sustitucion.ForeColor = System.Drawing.Color.Black;
            this.btn_sustitucion.Location = new System.Drawing.Point(0, 0);
            this.btn_sustitucion.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btn_sustitucion.Name = "btn_sustitucion";
            this.btn_sustitucion.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.btn_sustitucion.Size = new System.Drawing.Size(219, 24);
            this.btn_sustitucion.TabIndex = 0;
            this.btn_sustitucion.Text = "Sustitucion";
            this.btn_sustitucion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_sustitucion.UseVisualStyleBackColor = false;
            this.btn_sustitucion.Click += new System.EventHandler(this.btn_sustitucion_Click);
            // 
            // btnMedios
            // 
            this.btnMedios.BackColor = System.Drawing.Color.AliceBlue;
            this.btnMedios.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnMedios.FlatAppearance.BorderSize = 0;
            this.btnMedios.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMedios.ForeColor = System.Drawing.Color.Black;
            this.btnMedios.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnMedios.Location = new System.Drawing.Point(0, 94);
            this.btnMedios.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.btnMedios.Name = "btnMedios";
            this.btnMedios.Padding = new System.Windows.Forms.Padding(9, 0, 0, 0);
            this.btnMedios.Size = new System.Drawing.Size(219, 42);
            this.btnMedios.TabIndex = 1;
            this.btnMedios.Text = "Algebra";
            this.btnMedios.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMedios.UseVisualStyleBackColor = false;
            this.btnMedios.Click += new System.EventHandler(this.btnMedios_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(219, 94);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.AliceBlue;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(219, 94);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // panelChildForm
            // 
            this.panelChildForm.BackColor = System.Drawing.Color.AliceBlue;
            this.panelChildForm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelChildForm.BackgroundImage")));
            this.panelChildForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelChildForm.Cursor = System.Windows.Forms.Cursors.Default;
            this.panelChildForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelChildForm.Location = new System.Drawing.Point(219, 0);
            this.panelChildForm.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panelChildForm.Name = "panelChildForm";
            this.panelChildForm.Size = new System.Drawing.Size(592, 575);
            this.panelChildForm.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(811, 575);
            this.Controls.Add(this.panelChildForm);
            this.Controls.Add(this.panel_lateral);
            this.Font = new System.Drawing.Font("Leelawadee", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Name = "Form1";
            this.Text = "calculadora";
            this.panel_lateral.ResumeLayout(false);
            this.panel_mate.ResumeLayout(false);
            this.panel_algebra.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_lateral;
        private System.Windows.Forms.Panel panel_algebra;
        private System.Windows.Forms.Button btn_determinantes;
        private System.Windows.Forms.Button btn_igualacion;
        private System.Windows.Forms.Button btn_eliminacion;
        private System.Windows.Forms.Button btn_sustitucion;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_vectores;
        private System.Windows.Forms.Button btn_grafica;
        private System.Windows.Forms.Button btn_mate;
        private System.Windows.Forms.Panel panelChildForm;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnMedios;
        private System.Windows.Forms.Panel panel_mate;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
    }
}

